﻿using Newtonsoft.Json;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApp1
{

    internal class Program
    {
        public static SqlConnection sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionSql"].ConnectionString);
        public static SqlCommand coommand = new SqlCommand();

        static void Main(string[] args)
        {
            try
            {
                MoficarDatos();
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void MoficarDatos()
        {
            try
            { 
                coommand.Connection = sqlConnection;
                sqlConnection.Open();

                //ALTERAR LA TABLA PARA METER 3 NUEVAS COLUMNAS Costo Modificado, Fecha Inicio,  Fecha FIN
                coommand.CommandText = "ALTER TABLE [dbo].[libros] ADD CostoModificado int NULL, fechaIncio DATETIME, fechaFin DATETIME";
                var escribirDatos = coommand.ExecuteReader();
                var leerTabla = new DataTable();
                leerTabla.Load(escribirDatos);

                //INSERTAR DATOS NUEVOS EN LA TABLA
                coommand.CommandText = "update libros set CostoModificado = '10' where Vendido = 'NO'";
                coommand.ExecuteNonQuery();

                //MODIFICAR FECHA
                coommand.CommandText = "update libros set fechaIncio ='01/01/2010'";
                coommand.CommandText = "update libros set fechaFin = FechaEdicion where Vendido = 'NO'";
                coommand.ExecuteNonQuery();

                sqlConnection.Close();
              var json = JsonConvert.SerializeObject(leerTabla);

              
              Console.WriteLine(json);
              Console.ReadLine();

      

            }
            catch (SqlException e)
            {
                Console.WriteLine(e.Message);

            }
        }

    }
}
